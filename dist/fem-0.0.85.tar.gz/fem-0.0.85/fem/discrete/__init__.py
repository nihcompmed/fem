name = 'discrete'

from fit import *
from simulate import *
from combinatorics import *
