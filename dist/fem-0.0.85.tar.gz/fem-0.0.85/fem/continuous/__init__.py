name = 'continuous'

from fit import *
from simulate import *
